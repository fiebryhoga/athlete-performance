import React from "react";
import { Scale, Activity, Flame, Zap, Compass } from "lucide-react";

const MetricGauge = ({
    label,
    value,
    unit,
    ranges,
    maxGaugeValue = 40,
    icon: Icon,
}) => {
    if (value === null || value === undefined || value === "") return null;

    const val = parseFloat(value);
    const positionPct = Math.min(100, Math.max(0, (val / maxGaugeValue) * 100));

    let currentCategory = { label: "Di luar rentang", color: "gray" };
    Object.values(ranges || {}).forEach((range) => {
        if (val >= range.min && val <= range.max) {
            currentCategory = range;
        }
    });

    const bgColors = {
        blue: "bg-blue-500",
        green: "bg-emerald-500",
        lime: "bg-teal-500",
        yellow: "bg-amber-400",
        orange: "bg-orange-500",
        red: "bg-rose-500",
        gray: "bg-slate-400",
    };

    const textColors = {
        blue: "text-blue-600",
        green: "text-emerald-600",
        lime: "text-teal-600",
        yellow: "text-amber-600",
        orange: "text-orange-600",
        red: "text-rose-600",
        gray: "text-slate-500",
    };

    return (
        <div className="bg-gradient-to-b from-white to-slate-50/70 border border-slate-200/80 rounded-lg p-3.5 shadow-2xs space-y-2.5">
            <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                    {Icon && (
                        <div className="w-6 h-6 rounded-md bg-orange-50 text-orange-600 flex items-center justify-center shrink-0 border border-orange-100">
                            <Icon className="w-3.5 h-3.5" />
                        </div>
                    )}
                    <div>
                        <p className="text-xs font-bold text-slate-800 leading-tight">
                            {label}
                        </p>
                        <p className="text-lg font-black tracking-tight text-slate-900 mt-0.5">
                            {val}{" "}
                            <span className="text-xs font-bold text-slate-400">
                                {unit}
                            </span>
                        </p>
                    </div>
                </div>
                <div className="text-right">
                    <span
                        className={`text-[11px] font-bold ${
                            textColors[currentCategory.color] || textColors.gray
                        }`}
                    >
                        {currentCategory.label}
                    </span>
                </div>
            </div>

            {/* Gauge Track */}
            <div className="relative w-full h-2.5 bg-slate-200/80 rounded-full overflow-hidden">
                {Object.values(ranges || {}).map((r, i) => {
                    const rMax = Math.min(r.max, maxGaugeValue);
                    const left = (r.min / maxGaugeValue) * 100;
                    const width = Math.max(
                        0,
                        ((rMax - r.min) / maxGaugeValue) * 100,
                    );
                    return (
                        <div
                            key={i}
                            className={`absolute h-full opacity-60 ${
                                bgColors[r.color] || "bg-slate-300"
                            }`}
                            style={{
                                left: `${left}%`,
                                width: `${width}%`,
                            }}
                            title={`${r.label}: ${r.min} - ${r.max}`}
                        />
                    );
                })}
            </div>

            {/* Needle indicator below track */}
            <div className="relative w-full h-2">
                <div
                    className="absolute -top-3.5 -translate-x-1/2 w-3.5 h-3.5 bg-white border-2 border-slate-900 rounded-full shadow-md z-10 transition-all duration-500"
                    style={{ left: `${positionPct}%` }}
                />
            </div>

            <div className="flex justify-between text-[9.5px] text-slate-400 font-bold -mt-1">
                <span>0</span>
                <span>
                    Batas {maxGaugeValue} {unit}
                </span>
            </div>
        </div>
    );
};

export default function AnalyticsDashboard({ test, player, benchmarks }) {
    if (!test || !benchmarks) return null;

    const isMale =
        player?.gender === "male" ||
        player?.gender === "L" ||
        player?.gender === "Laki-laki" ||
        !player?.gender;
    const bfBenchmarks = isMale
        ? benchmarks.body_fat?.male
        : benchmarks.body_fat?.female;

    return (
        <div className="bg-white border border-slate-200/80 rounded-lg p-4 sm:p-5 shadow-2xs space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                    <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <Activity className="w-3.5 h-3.5 text-orange-500" />
                        Ambang Batas & Benchmark Bioimpedansi
                    </h3>
                    <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                        Posisi nilai aktual atlet pada indikator batas acuan
                        standar ({isMale ? "Putra" : "Putri"}).
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <MetricGauge
                    label="Persentase Lemak (Body Fat)"
                    value={test.body_fat_percentage}
                    unit="%"
                    ranges={bfBenchmarks}
                    maxGaugeValue={35}
                    icon={Flame}
                />
                <MetricGauge
                    label="Lemak Visceral"
                    value={test.visceral_fat}
                    unit="Lvl"
                    ranges={benchmarks.visceral_fat}
                    maxGaugeValue={20}
                    icon={Flame}
                />
                <MetricGauge
                    label="Indeks Massa Tubuh (BMI)"
                    value={test.bmi}
                    unit=""
                    ranges={benchmarks.bmi}
                    maxGaugeValue={35}
                    icon={Scale}
                />
                <MetricGauge
                    label="Phase Angle (Kualitas Seluler)"
                    value={test.phase_angle}
                    unit="°"
                    ranges={benchmarks.phase_angle}
                    maxGaugeValue={12}
                    icon={Zap}
                />
            </div>
        </div>
    );
}
