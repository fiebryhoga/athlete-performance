import React, { useState } from "react";
import AppLayout from "@/Layouts/AppLayout";
import { Head, usePage, Link } from "@inertiajs/react";
import {
    Activity,
    Plus,
    Scale,
    ChevronLeft,
    Flame,
    Zap,
    HeartPulse,
    Calendar,
    User,
    ArrowLeft,
    Sparkles,
} from "lucide-react";

import PageHeader from "@/Components/Common/PageHeader";
import PageFooter from "@/Components/Common/PageFooter";
import TrendHighlights from "./Partials/TrendHighlights";
import CompositionAnatomy from "./Partials/CompositionAnatomy";
import AnalyticsDashboard from "./Partials/AnalyticsDashboard";
import SmartInsights from "./Partials/SmartInsights";
import HistoryTable from "./Partials/HistoryTable";
import CompositionFormModal from "./Partials/CompositionFormModal";
import TdeeSummary from "./Partials/TdeeSummary";

export default function Show({ auth, player, history = [], benchmarks = {} }) {
    const isAthlete = auth?.user?.role === "athlete";
    const { permissions } = usePage().props;
    const canCreate = permissions?.body_composition?.create ?? true;

    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [editingRecord, setEditingRecord] = useState(null);

    const latestTest = history.length > 0 ? history[0] : null;

    const handleEdit = (record) => {
        setEditingRecord(record);
        setIsFormModalOpen(true);
    };

    const handleAddRecord = () => {
        setEditingRecord(null);
        setIsFormModalOpen(true);
    };

    // Helper initials
    const getInitials = (name) => {
        if (!name) return "??";
        const words = name.trim().split(" ");
        if (words.length >= 2) {
            return `${words[0][0]}${words[1][0]}`.toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    };

    const isFemale =
        player?.gender === "P" ||
        player?.gender === "female" ||
        player?.gender === "Perempuan";
    const genderLabel = isFemale ? "Putri" : "Putra";

    const formatDate = (dateString) => {
        if (!dateString) return "-";
        return new Date(dateString).toLocaleDateString("id-ID", {
            day: "numeric",
            month: "long",
            year: "numeric",
        });
    };

    return (
        <AppLayout
            title={`Komposisi Tubuh - ${player.name}`}
            description={`Analisis detail komposisi tubuh, massa otot, persentase lemak, dan performa seluler atlet ${player.name}.`}
        >
            <Head title={`Komposisi Tubuh - ${player.name}`} />

            <div className="space-y-4 pb-10">
                {/* ─── PAGE HEADER & ACTIONS ─── */}
                <PageHeader
                    title={`Analisis Komposisi Tubuh ${player.name}`}
                    description={`Evaluasi bioimpedansi atlet, distribusi jaringan otot, lemak tubuh, dan metabolisme.`}
                    badge="Bioimpedansi"
                    icon={Scale}
                    actions={
                        <>
                            {!isAthlete && (
                                <Link
                                    href={route(
                                        "admin.composition-tests.index",
                                    )}
                                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-md text-xs font-bold transition-all shadow-2xs"
                                >
                                    <ArrowLeft className="w-3.5 h-3.5" />
                                    <span>Kembali</span>
                                </Link>
                            )}

                            {!isAthlete && canCreate && (
                                <button
                                    type="button"
                                    onClick={handleAddRecord}
                                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white rounded-md text-xs font-bold transition-all shadow-sm hover:shadow"
                                >
                                    <Plus className="w-3.5 h-3.5" />
                                    <span>Tambah Data</span>
                                </button>
                            )}
                        </>
                    }
                />

                {/* ─── ATHLETE HERO PROFILE CARD ─── */}
                <div className="bg-gradient-to-b from-white via-orange-50/15 to-orange-50/30 rounded-lg border border-slate-200/90 p-4 sm:p-5 shadow-2xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    {/* Athlete Avatar & Metadata */}
                    <div className="flex items-center gap-3.5 min-w-0">
                        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl border-2 border-white shadow-sm bg-gradient-to-br from-orange-100 to-amber-100 text-orange-600 font-black text-xl flex items-center justify-center shrink-0 overflow-hidden">
                            {player.photo_url ? (
                                <img
                                    src={player.photo_url}
                                    alt={player.name}
                                    className="w-full h-full object-cover"
                                />
                            ) : (
                                <span>{getInitials(player.name)}</span>
                            )}
                        </div>

                        <div className="min-w-0 space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                                <h2 className="text-base sm:text-lg font-black text-slate-900 leading-tight">
                                    {player.name}
                                </h2>
                                <span className="px-2 py-0.5 rounded text-[10.5px] font-bold bg-orange-50 text-orange-700 border border-orange-200/70">
                                    {player.sport?.name || "Tanpa Cabor"} (
                                    {genderLabel})
                                </span>
                            </div>

                            <div className="flex items-center gap-3 text-xs text-slate-500 font-medium flex-wrap">
                                {player.age && (
                                    <span>
                                        Usia: <strong>{player.age} thn</strong>
                                    </span>
                                )}
                                {latestTest?.height && (
                                    <>
                                        <span className="text-slate-300">
                                            •
                                        </span>
                                        <span>
                                            Tinggi:{" "}
                                            <strong>
                                                {latestTest.height} cm
                                            </strong>
                                        </span>
                                    </>
                                )}
                                {latestTest?.weight && (
                                    <>
                                        <span className="text-slate-300">
                                            •
                                        </span>
                                        <span>
                                            Berat:{" "}
                                            <strong>
                                                {latestTest.weight} kg
                                            </strong>
                                        </span>
                                    </>
                                )}
                                {latestTest?.bmi && (
                                    <>
                                        <span className="text-slate-300">
                                            •
                                        </span>
                                        <span>
                                            BMI:{" "}
                                            <strong>{latestTest.bmi}</strong>
                                        </span>
                                    </>
                                )}
                            </div>

                            {latestTest?.date && (
                                <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1 pt-0.5">
                                    <Calendar className="w-3 h-3 text-slate-400" />
                                    Evaluasi Terakhir:{" "}
                                    {formatDate(latestTest.date)}
                                </p>
                            )}
                        </div>
                    </div>

                    {/* Quick Metric Pills */}
                    {latestTest && (
                        <div className="flex items-center gap-2 sm:gap-3 self-stretch md:self-auto justify-between md:justify-end border-t md:border-t-0 pt-3 md:pt-0 border-slate-100 overflow-x-auto">
                            <div className="px-3 py-2 bg-white/90 rounded-md border border-slate-200/80 text-center shadow-2xs min-w-[70px]">
                                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                                    Body Fat
                                </span>
                                <span className="text-sm font-black text-orange-600">
                                    {latestTest.body_fat_percentage
                                        ? `${latestTest.body_fat_percentage}%`
                                        : "-"}
                                </span>
                            </div>

                            <div className="px-3 py-2 bg-white/90 rounded-md border border-slate-200/80 text-center shadow-2xs min-w-[70px]">
                                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                                    Massa Otot
                                </span>
                                <span className="text-sm font-black text-teal-700">
                                    {latestTest.muscle_mass
                                        ? `${latestTest.muscle_mass} kg`
                                        : "-"}
                                </span>
                            </div>

                            <div className="px-3 py-2 bg-white/90 rounded-md border border-slate-200/80 text-center shadow-2xs min-w-[70px]">
                                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                                    Visceral
                                </span>
                                <span className="text-sm font-black text-slate-800">
                                    {latestTest.visceral_fat
                                        ? `Lvl ${latestTest.visceral_fat}`
                                        : "-"}
                                </span>
                            </div>

                            <div className="px-3 py-2 bg-white/90 rounded-md border border-slate-200/80 text-center shadow-2xs min-w-[70px]">
                                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                                    Phase Angle
                                </span>
                                <span className="text-sm font-black text-indigo-600">
                                    {latestTest.phase_angle
                                        ? `${latestTest.phase_angle}°`
                                        : "-"}
                                </span>
                            </div>
                        </div>
                    )}
                </div>

                {/* ─── MAIN CONTENT ─── */}
                {latestTest ? (
                    <div className="space-y-4">
                        {/* 19 Biomarker Categories Grid */}
                        <TrendHighlights history={history} />

                        {/* Dual Dashboard Visualizations */}
                        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
                            <div className="xl:col-span-2 flex flex-col space-y-4">
                                <AnalyticsDashboard
                                    test={latestTest}
                                    player={player}
                                    benchmarks={benchmarks}
                                />
                                <CompositionAnatomy
                                    test={latestTest}
                                    player={player}
                                />
                            </div>

                            <div className="xl:col-span-1 flex flex-col h-full">
                                <SmartInsights
                                    test={latestTest}
                                    player={player}
                                    benchmarks={benchmarks}
                                />
                            </div>
                        </div>

                        {/* Caloric & Macronutrient Target */}
                        <TdeeSummary test={latestTest} player={player} />
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center shadow-2xs">
                        <div className="w-14 h-14 rounded-xl bg-orange-50 border border-orange-100 flex items-center justify-center mb-3 text-orange-500 shadow-2xs">
                            <Scale className="w-7 h-7" />
                        </div>
                        <h3 className="text-base font-bold text-slate-900 mb-1">
                            Belum Ada Data Evaluasi Komposisi Tubuh
                        </h3>
                        <p className="text-xs text-slate-500 max-w-md mx-auto mb-5 leading-relaxed">
                            Atlet ini belum memiliki catatan riwayat
                            bioimpedansi. Tambahkan data pengukuran pertama
                            untuk melihat analisis mendalam.
                        </p>
                        {!isAthlete && canCreate && (
                            <button
                                type="button"
                                onClick={handleAddRecord}
                                className="inline-flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white rounded-md text-xs font-bold transition-all shadow-sm"
                            >
                                <Plus className="w-4 h-4" />
                                <span>Input Data Pertama</span>
                            </button>
                        )}
                    </div>
                )}

                {/* ─── HISTORY TABLE ─── */}
                <div className="pt-1">
                    <HistoryTable
                        history={history}
                        onEdit={!isAthlete ? handleEdit : null}
                        canDelete={!isAthlete}
                    />
                </div>

                <PageFooter />
            </div>

            {/* Modal Input & Edit Data */}
            <CompositionFormModal
                isOpen={isFormModalOpen}
                onClose={() => setIsFormModalOpen(false)}
                player={player}
                record={editingRecord}
            />
        </AppLayout>
    );
}
